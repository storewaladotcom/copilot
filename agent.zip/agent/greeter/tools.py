"""
This file contains all the tools that are used in the wiz_agent.py file.
"""
from datetime import datetime, timedelta
import json
import random
import string
from typing import List, Any
from langchain_core.tools import tool
from langchain_core.runnables import RunnableConfig
from langchain_openai import ChatOpenAI


pa_prompt = """
You are a customer support assistant for Wizcommerce, a B2B platform helping wholesalers sell efficiently to retailers. You have following assistants within you:
Recommendation Assistant: AI features like "view similar," "frequently bought together," recommendations, or generic term searches.
Cart Assistant: Add/remove products, fetch cart info, or summaries.
Payment Assistant: Payment-related queries.
Customer Assistant: Customer-level info or summaries.
Product Assistant: Product details via sku_id.
Order Assistant: Order-related queries (not cart).
"""

cart_agent_prompt = """This agent handles all cart-related actions (distinct from order-related actions). It has four tools:
                        add_to_cart: Adds products to a customer's cart using a list of sku_ids and either customer_id or customer_name.
                        remove_from_cart: Removes products from a customer's cart using a list of sku_ids and either customer_id or customer_name.
                        cart_info: Fetches the list, price, and quantity of products in the cart for a given customer using either customer_id or customer_name.
                        cart_summary: Provides a cart summary (total value, product count, last updated time) using either customer_id or customer_name.
                        """

recommendation_agent_prompt = """This agent handles 4 features related to AI or product search: 
                                View Similar: Shows visually similar products for a given product using its sku_id.
                                Frequently Bought Together: Displays products frequently purchased with a specific product using its sku_id.
                                Buyer-Product Recommendations: Provides tailored product recommendations for a buyer using either buyer_id or buyer_name.
                                Smart Search: Finds products matching a generic search term, requiring only the term (no sku_id, buyer_id, or buyer_name).
                            """

# load_dotenv()
# api_key = os.getenv("OPENAI_API_KEY")

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.5)

#primary assistant tool

@tool
def fetch_info(config: RunnableConfig) -> list[dict]: # pylint: disable=unused-argument
    """
        this gives the basic information about the user who is having the conversation
    
    """
    return [
        {
            "tenant_id": "3442 587242",
            "thread_id": 12579,
        }
    ]


#recommendation tools

@tool
def show_products(products: List[str]): # pylint: disable=unused-argument
    """Call this tool whenever you are showing similar products"""
    print("inside show_products")


@tool
def view_similar(sku_id: str = "", image_url: str = "") -> Any:
    """
    This tool shows similar looking products of any SKU or product. It requires either SKU ID or image_url of the product as 
    parameter.

    Args:
        sku_id (str): The SKU ID of the product.
        image_url (str): The URL of an image for which similar products are to be fetched.

    Returns:
        dict: Details of the similar products
    """
    # Ensure that either sku_id or image_url is provided
    if not (sku_id or image_url):
        raise ValueError("Either sku_id or image_url must be provided.")
    
    random_skus = [''.join(random.choices(string.ascii_uppercase + string.digits, k=8)) for _ in range(5)]
    
    return [
        {
            "id": "8f6a1d0b-e1dc-4410-ba50-3f5a3ba95e0f",
            "image_url": "https://fileserver-g-p.sourcerer.tech/files/bae5b8b5-b43b-41a5-9081-55813ec6e2a5",
            "product" : sku_id,
            "price"  : "$100"
        }
        for sku_id in random_skus
    ]

@tool
def fbt(sku_id: str = "") -> Any:
    """
    This tool shows a list of products which are frequently bought together with the given product. It requires either SKU ID of product as 
    parameter.

    Args:
        sku_id (str): The SKU ID of the product.

    Returns:
        dict: Details of the frequently bought products
    """
    # Ensure that either sku_id or image_url is provided
    if not (sku_id):
        raise ValueError("sku_id must be provided")
    
    random_skus = [''.join(random.choices(string.ascii_uppercase + string.digits, k=8)) for _ in range(5)]
    
    return [
        {
            "id": "8f6a1d0b-e1dc-4410-ba50-3f5a3ba95e0f",
            "image_url": "https://fileserver-g-p.sourcerer.tech/files/bae5b8b5-b43b-41a5-9081-55813ec6e2a5",
            "product" : sku_id,
            "price"  : "200"
        }
        for sku_id in random_skus
    ]

@tool
def reco(buyer_id:str = "", buyer_name:str = "") -> Any:
    """
    This tool shows a list of products which are recommended for a particular buyer. It covers tailor made product recommendations for each buyer/customer. 
    It requires either buyer id or buyer name of buyer/customer as parameter. buyer name is sufficient as parameter on its own, buyer id is also sufficient as parameter on its own. no need to have both. 

    Args:
        buyer_id (str): The id of the buyer/customer.
        buyer_name (str): The name of the buye/customer.

    Returns:
        dict: Details of the products which are recommended for this buyer/customer
    """
    # Ensure that either sku_id or image_url is provided
    if not (buyer_id or buyer_name):
        raise ValueError("sku_id must be provided")
    
    random_skus = [''.join(random.choices(string.ascii_uppercase + string.digits, k=8)) for _ in range(5)]
    
    return [
        {
            "id": "8f6a1d0b-e1dc-4410-ba50-3f5a3ba95e0f",
            "image_url": "https://fileserver-g-p.sourcerer.tech/files/bae5b8b5-b43b-41a5-9081-55813ec6e2a5",
            "product" : sku_id,
            "price"  : "300"
        }
        for sku_id in random_skus
    ]


@tool
def smart_search(term:str = "") -> Any:
    """
    If user wants to search about any product using generic language term instead of proper product or sku id, then use this tool.
    this tool can take a text and search the products on the basis of that text.
    parameter. 

    Args:
        input_term (str): the term which user wants to search.
       

    Returns:
        dict: Details of the products.
    """
    # Ensure that either sku_id or image_url is provided
    if not (term):
        raise ValueError("no term was found to search")
    
    random_skus = [''.join(random.choices(string.ascii_uppercase + string.digits, k=8)) for _ in range(5)]
    
    return [
        {
            "id": "8f6a1d0b-e1dc-4410-ba50-3f5a3ba95e0f",
            "image_url": "https://fileserver-g-p.sourcerer.tech/files/bae5b8b5-b43b-41a5-9081-55813ec6e2a5",
            "product" : sku_id,
            "price"  : "400"
        }
        for sku_id in random_skus
    ]


#cart_agent

@tool
def add_to_cart(customer_id: str = "", sku_ids: List[str] = [], customer_name: str = "") -> dict:
    """
    Add the specified SKU IDs to the cart for the given customer. It requires either customer id of customer name. no need to have both of them, but one of them must be there.

    Args:
        customer_id (str): The customer ID of the customer.
        sku_ids (List[str]): A list of SKU IDs for products to be added to the cart.
        customer_name (str): The name of the customer.

    Returns:
        dict: json of sku_ids which have been added to cart successfully.
    """
    # Ensure that either customer_id or customer_name is provided
    if not (customer_id or customer_name):
        raise ValueError("Either customer_id or customer_name must be provided.")
    
    # Ensure that sku_ids is provided and is not empty
    if not sku_ids:
        raise ValueError("At least one SKU ID must be provided.")

    # Simulate adding SKUs to cart and return a summary
    response = {
        "sku_ids": [
            {"sku_id": sku_id, "message": f"SKU ID {sku_id} has been added to the cart successfully."}
            for sku_id in sku_ids
        ]
    }

    return response

@tool
def remove_from_cart(customer_id: str = "", sku_ids: List[str] = [], customer_name: str = "") -> dict:
    """
    Removes the specified SKU IDs to the cart for the given customer. It requires either customer id of customer name. no need to have both of them, but one of them must be there.

    Args:
        customer_id (str): The customer ID of the customer.
        sku_ids (List[str]): A list of SKU IDs for products to be added to the cart.
        customer_name (str): The name of the customer.

    Returns:
        dict: json of sku_ids which have been added to cart successfully.
    """
    # Ensure that either customer_id or customer_name is provided
    if not (customer_id or customer_name):
        raise ValueError("Either customer_id or customer_name must be provided.")
    
    # Ensure that sku_ids is provided and is not empty
    if not sku_ids:
        raise ValueError("At least one SKU ID must be provided.")

    # Simulate adding SKUs to cart and return a summary
    response = {
        "sku_ids": [
            {"sku_id": sku_id, "message": f"SKU ID {sku_id} has been removed from the cart successfully."}
            for sku_id in sku_ids
        ]
    }

    return response


#function to generate random values for now
def generate_cart_item():
    return {
        "sku_id": str(random.randint(100000, 999999)),
        "price": round(random.uniform(10.0, 100.0), 2),
        "quantity": random.randint(1, 10)
    }

# Generate a sample cart summary dynamically
def generate_cart_summary():
    return {
        "total_items": random.randint(1, 50),  # Random total items in cart
        "total_value": round(random.uniform(50.0, 1000.0), 2),  # Random total cart value
        "last_updated": datetime.now().isoformat()  # Current timestamp
    }


@tool
def cart_info(customer_id: str = "", customer_name: str = "") -> str:
    """
    It gives the list of sku_ids, their quantity, and price of products which are in cart currently. It requires either customer_id or customer_name as parameter, it does not need both of them at the same time. 

    Args:
        customer_id (str): The customer ID of the customer.
        customer_name (str): The name of the customer.

    Returns:
        dict: details of cart in json.
    """
    # Ensure that either customer_id or customer_name is provided
    if not (customer_id or customer_name):
        raise ValueError("Either customer_id or customer_name must be provided.")
    
   
    
    # Create dynamic cart details
    cart_details = {
        "cart_items": [generate_cart_item() for _ in range(5)]  # Generate 5 random items
    }
    
    # Convert to JSON
    cart_details_json = json.dumps(cart_details, indent=4)

    return cart_details_json




@tool
def cart_summary(customer_id: str = "", customer_name: str = "") -> str:
    """
    It gives summary of the cart, like total value, no of items, when it was last updated, etc. It requires either customer_name or customer_id, both of them are not required at the same time. one is enough.
    Args:
        customer_id (str): The customer ID of the customer.
        customer_name (str): The name of the customer.

    Returns:
        json: cart summary in json format
    """
    # Ensure that either customer_id or customer_name is provided
    if not (customer_id or customer_name):
        raise ValueError("Either customer_id or customer_name must be provided.")
    
   
    
    # Create dynamic cart details
    # Generate and print a dynamic cart summary
    cart_summary = generate_cart_summary()
    cart_summary_json = json.dumps(cart_summary, indent=4)
    
    
    return cart_summary_json


#payment_agent

@tool
def payment_info(order_id: str = "") -> dict:
    """
    This tool shows the payment information an order.

    Args:
        order_id (str): The order ID of the order for which payment details are to be fetched.
        

    Returns:
        dict: A summary of the payment details in a specified JSON format.
    """
    # Ensure that either order_id or invoice_id is provided
    if not (order_id):
        raise ValueError("order_id was not provided")
    
    # Default values if only one of them is given
    order_id = order_id or f"ORD{random.randint(10000, 99999)}"


    # Generate random values for the payment summary
    total_outstanding = round(random.uniform(100, 1000), 2)
    total_paid = round(random.uniform(10000, 20000), 2)

    return {
        "paymentSummary": {
            "totalOutstanding": total_outstanding,
            "totalPaid": total_paid,
            "pendingInvoices": [
                {
                    "order": order_id,
                    "amount": round(random.uniform(100, 300), 2),
                    "dueDate": (datetime.now() + timedelta(days=random.randint(1, 15))).strftime("%Y-%m-%d"),
                    "status": "Unpaid"
                },
            
            ]
        }
    }


#Customer agent

@tool
def customer_summary(customer_id: str = "", customer_name: str = "") -> dict:
    """
    This tool shows the overall summary of a customer like, total amount purchased by customer till date, no of orders, most recent orders, etc.
    It requires either customer name or customer id. Both of them are not required at the same time.
    Args:
        customer_id (str): The id of the customer whose summary is to be shown.
        customer_name(str): The name of the customer whose summary is to be shown.
    Returns:
        dict: A summary of the customer in json format..
    """
    # Ensure that either order_id or invoice_id is provided
    if not (customer_id or customer_name):
        raise ValueError("neither customer name nor customer id was provided")
    
    # Default values if only one of them is given
   
    return {
      "customer_summary": {
        "customer_id": customer_id if customer_id else "CUST12345",
        "customer_name": customer_name if customer_name else "Ayush",
        "total_order_value": 12500.50,
        "total_orders_count": 35,
        "most_recent_order": {
          "order_id": "ORD78901",
          "order_date": "2024-12-15",
          "order_value": 350.75
        },
        "average_order_value": 357.15,
        "first_order_date": "2019-03-25",
        "most_purchased_category": "Electronics",
        "preferred_payment_method": "Credit Card",
        "last_active_date": "2024-12-18"
      }
    }
    

@tool
def customer_info(customer_id: str = "", customer_name: str = "") -> dict:
    """
    This tool shows the basic meta data information of the customer like, Country, Shipping Address, Billing Address, Email, Contact No., etc.
    It requires either customer name or customer id. Both of them are not required at the same time.
    Args:
        customer_id (str): The id of the customer whose details are to be shown.
        customer_name(str): The name of the customer whose details are to be shown.
    Returns:
        dict: The basic details of the customer in json format..
    """
    # Ensure that either order_id or invoice_id is provided
    if not (customer_id or customer_name):
        raise ValueError("neither customer name nor customer id was provided")
    
    # Default values if only one of them is given
   
    return {
      "customer_info": {
        "customer_id": customer_id if customer_id else "CUST12345",
        "customer_name": customer_name if customer_name else "John Doe",
        "email": "johndoe@example.com",
        "contact_number": "+1-123-456-7890",
        "country": "United States",
        "shipping_address": {
          "address_line_1": "123 Main St",
          "address_line_2": "Apt 4B",
          "city": "New York",
          "state": "NY",
          "postal_code": "10001",
          "country": "United States"
        },
        "billing_address": {
          "address_line_1": "456 Elm St",
          "city": "Brooklyn",
          "state": "NY",
          "postal_code": "11201",
          "country": "United States"
        }
      }
    }
    
        
        
#product_agent

@tool
def product_info(sku_id: str = "") -> dict:
    """
    This tool shows the product information an order.

    Args:
        sku_id (str): The SKU ID of the product whose details are to be fetched.
        

    Returns:
        dict: A summary of the product details in a specified JSON format.
    """
    # Ensure that either order_id or invoice_id is provided
    if not (sku_id):
        raise ValueError("sku_id was not provided")
    
    

    return {
        "ProductSummary": {
            "Name": "Yellow Rug",
            "SKU ID": sku_id,
            "Description" : "A very very big yellow rug",
            "Price": "$1000",
            "Status" :"Avaialable",
        }
    }



#order_agent


@tool
def order_info(order_id: str = "") -> dict:
    """
    This tool shows the details of an order, like products in it, their quantity, status, etc.

    Args:
        order_id (str): The id of the order whose details are to be shown.
        

    Returns:
        dict: Details of order
    """
    # Ensure that either order_id or invoice_id is provided
    if not (order_id):
        raise ValueError("order_id was not provided")
    
    

    return {
      "order_details": {
        "order_id": order_id,
        "customer_name": "John Doe",
        "billing_address": {
          "address_line_1": "456 Elm St",
          "city": "Brooklyn",
          "state": "NY",
          "postal_code": "11201",
          "country": "United States"
        },
        "shipping_address": {
          "address_line_1": "123 Main St",
          "address_line_2": "Apt 4B",
          "city": "New York",
          "state": "NY",
          "postal_code": "10001",
          "country": "United States"
        },
        "items": [
          {
            "sku_id": "SKU001",
            "item_name": "Wireless Mouse",
            "price": 25.99,
            "quantity": 2,
            "total_price": 51.98
          },
          {
            "sku_id": "SKU002",
            "item_name": "Keyboard",
            "price": 45.49,
            "quantity": 1,
            "total_price": 45.49
          },
          {
            "sku_id": "SKU003",
            "item_name": "Monitor",
            "price": 199.99,
            "quantity": 1,
            "total_price": 199.99
          }
        ],
        "total_order_value": 297.46,
        "status": "Shipped"
      }
    }
    

@tool
def order_summary(order_id: str = "") -> dict:
    """
    This tool shows the summary of an order,like total items in it, total order value, etc.

    Args:
        order_id (str): The id of the order whose details are to be shown.
        

    Returns:
        dict: Details of order
    """
    # Ensure that either order_id or invoice_id is provided
    if not (order_id):
        raise ValueError("order_id was not provided")
    
    return {
      "order_summary": {
        "order_id": order_id,
        "customer_name": "John Doe",
        "number_of_items": 4,
        "total_order_value": 297.46
      }
    }

@tool
def create_order(customer_id: str = "", sku_ids: List[str] = [], customer_name: str = "") -> str:
    """
    This tool creates an order. It requires customer id or customer name, and list of products in the form of sku_ids 
    Args:
        customer_id (str): The customer ID of the customer.
        sku_ids (List[str]): A list of SKU IDs for products to be included in cart.
        customer_name (str): The name of the customer.

    Returns:
        string: A message telling whether the order has been created or not.
    """
    # Ensure that either customer_id or customer_name is provided
    if not (customer_id or customer_name):
        raise ValueError("Either customer_id or customer_name must be provided.")
    
    # Ensure that sku_ids is provided and is not empty
    if not sku_ids:
        raise ValueError("At least one SKU ID must be provided.")

    # Simulate adding SKUs to cart and return a summary
    response = "Order has been successfully created with order_id : ORD12345"

    return response

@tool
def shipment_info(order_id: str) -> dict:

    """
    Show the shipment details of the order.

    Args:
        order_id (str): The order ID of the order for which shipment details is to be fetched.
    Returns:
        dict: shipment details of the order in json format
    """

    shipment_summary = {
        "order_id":order_id,
        "status":"In Transit",
    }
        
    return shipment_summary

