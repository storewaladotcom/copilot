from datetime import datetime
from typing import Annotated, Literal, Optional, Callable, List
from typing_extensions import TypedDict

from pydantic import BaseModel, Field
from langchain_core.messages import ToolMessage
from langchain_core.runnables import RunnableLambda
from langchain_core.runnables import Runnable, RunnableConfig
from langchain_core.prompts import ChatPromptTemplate
from langgraph.prebuilt import tools_condition
from langgraph.graph import END, StateGraph, START
from langgraph.graph.message import AnyMessage, add_messages
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver
from .tools import llm, fetch_info, show_products, view_similar, fbt, reco, smart_search, add_to_cart,remove_from_cart,cart_info,cart_summary, payment_info, customer_info,customer_summary, product_info , order_info,order_summary,create_order,shipment_info


# def update_dialog_stack(left: list[str], right:Optional[list[str]]) -> list[str]:
#     """Push or pop the state."""
#     if right is None:
#         return left
#     if right == "pop":
#         return left[:-1]
#     print("top",left+[right])
#     return left + [right]


def update_dialog_stack(left: list[str], right: Optional[list[str]]) -> list[str]:
    """Push or pop the state"""
    if right is None:
        return left
    if right == "pop":
        return left[:-1]
    if isinstance(right, list):
        # Prevent nested lists by extending instead of appending
        return left + right
    print("top",left + [right])
    return left + [right]

class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    user_info: str
    dialog_state: Annotated[
        list[
            Literal[
                "assistant",
                "recommendation_agent",
                "cart_agent",
                "payment_agent",
                "customer_agent",
                "product_agent",
                "order_agent",
            ]
        ],
        update_dialog_stack,
    ]



def user_info(state: State):
    print("state user info", state.get("messages"))    
    return {"user_info": fetch_info.invoke({})}




def route_tools(state: State):
    next_node = tools_condition(state)
    
    if next_node == END:
        return END
    ai_message = state["messages"][-1]

    first_tool_call = ai_message.tool_calls[0]
    if first_tool_call["name"] in [] :# sensitive_tool_names:
        return "sensitive_tools"
    return "safe_tools"


def _print_event(event: dict, _printed: set, max_length=1500):
    current_state = event.get("dialog_state")
    if current_state:
        print("Currently in: ", current_state[-1])
    message = event.get("messages")
    if message:
        if isinstance(message, list):
            message = message[-1]
        if message.id not in _printed:
            msg_repr = message.pretty_repr(html=True)
            if len(msg_repr) > max_length:
                msg_repr = msg_repr[:max_length] + " ... (truncated)"
            print(msg_repr)

_printed = set()            





def handle_tool_error(state) -> dict:
    error = state.get("error")
    tool_calls = state["messages"][-1].tool_calls
    return {
        "messages": [
            ToolMessage(
                content=f"Error: {repr(error)}\n please fix your mistakes.",
                tool_call_id=tc["id"],
            )
            for tc in tool_calls
        ]
    }
    
def create_tool_node_with_fallback(tools: list):
    return ToolNode(tools).with_fallbacks(
        [RunnableLambda(handle_tool_error)], exception_key="error"
    )


class Assistant:
    def __init__(self, runnable: Runnable):
        self.runnable = runnable

    def __call__(self, state: State, config: RunnableConfig):
        while True:
            result = self.runnable.invoke(state)

            if not result.tool_calls and (
                not result.content
                or isinstance(result.content, list)
                and not result.content[0].get("text")
            ):
                messages = state["messages"] + [("user", "Respond with a real output.")]
                state = {**state, "messages": messages}
                print("inside assistant if")
            else:
                print("inside assistant else")
                break
        print("result", result)
        return {"messages": [result]}


class CompleteOrEscalate(BaseModel):
    """A tool to mark the current task as completed and/or to escalate control of the dialog to the main assistant,
    who can re-route the dialog based on the user's needs."""

    cancel: bool = True
    reason: str

    class Config:
        json_schema_extra = {
            "example": {
                "cancel": True,
                "reason": "User changed their mind about the current task.",
            },
            "example 2": {
                "cancel": True,
                "reason": "I have fully completed the task.",
            },
            "example 3": {
                "cancel": False,
                "reason": "I need to search the user's emails or calendar for more information.",
            },
        }



#recommendation agent

recommendation_agent_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            this agent deals with 4 features (mainly AI related or any product search) of the platform, it has 4 tools for that. they are as follows:
            
            1. view similar - this feature shows similar looking products of any product given that sku_id (SKU ID) of that product is available. for this only sku id is required.
            2. frequently bought together - this feature shows products which have been bought frequently with a particular product. for this only sku id is required. 
                                            It also requires the sku_id (SKU ID) of that particular product for whom frequently bought together products are to be shown.
            3. buyer-product recommendations - this feature shows recommended products for a particular buyer. the recommendations are tailored for each buyer. 
                                               It requires either buyer_id or buyer_name of the buyer/customer for whom recommended products are to be shown. it does not need sku id or any product level information. it can work fully well with only buyer name too. buyer id is not compulsory. either one of buyer id or buyer name must be there.
            4. smart search - if user wants to search for any product using a generic term instead of particular any id, then this feature can show similar products to the searched term. this requires only search term, it neither needs sku id or buyer id or buyer name.
            5. show products - this feature returns the extracted products as the output.
            "\n\nCurrent user information:\n{user_info}\"
            "\nCurrent time: {time}."
            "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
            ' "CompleteOrEscalate" the dialog to the host assistant. Do not waste the user\'s time. Do not make up invalid tools or functions.',
            other assistants that are available and are outside of your scope are, escalate if any of those assistant can solve the problem:
            " 1. Cart assistant -> anything related to cart, like add or remove products from cart, pull cart information or summary, etc."
            " 2. Payment assistant -> any payment related query."
            " 3. Customer assistant -> all customer level information or summary in this assistant"
            " 4. Product assistant -> product level information only if user searches product using sku_id."
            " 5. Order assistannt -> order level information. this is the primary order assistant."
            
            """
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)

config = {
    "configurable": {
        "tenant_id": "3442 587242",
        "thread_id": 12579,
    }
}

recommendation_agent_safe_tools = [view_similar ,fbt ,reco ,smart_search ,show_products]
recommendation_agent_sensitive_tools = []
recommendation_agent_tools = recommendation_agent_safe_tools + recommendation_agent_sensitive_tools
recommendation_agent_runnable = recommendation_agent_prompt | llm.bind_tools(
    recommendation_agent_tools + [CompleteOrEscalate], parallel_tool_calls=False
)




#cart agent

cart_agent_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            this agent deals with everything related to cart. Note that order and cart are two different features, do not do the action on order if user has asked to perform action on cart or vice versa. there is a separate assistant for order related features or queries.
            it has 4 tools for that. they are as follows. in parameters it does not need both customer id and customer name, any one of them can do. ask for both only if one is failing, otherwise always try with one of them.:
            
            1. add_to_cart - this tool adds products into cart for a customer. it requires list of sku_ids of the products which are to be added and the customer_id/buyer_id or customer_name/buyer_name of the customer/buyer in whose cart the products are to be added. 
            2. remove_from_cart - this tool remove products from cart for a customer. it requires list of sku_ids of the products which are to be removed and the customer_id/buyer_id or customer_name/buyer_name of the customer/buyer in whose cart the products are to be removed. 
            3. cart_info - this tool fetches the list, price, and quantity of each product which are in cart currently for the given customer. it requires either customer_id/buyer_id or customer_name/buyer_name of the customer/buyer whose cart details are to be shown.
            4. cart_summary - it summarises the cart of a given customer. it shows information like total cart value, total number of products, when the cart was last updated, etc. it requires either customer_id/buyer_id or customer_name/buyer_name of the customer/buyer whose cart summary is to be shown.
            "\n\nCurrent user information:\n{user_info}\"
            "\nCurrent time: {time}."
            "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
            ' "CompleteOrEscalate" the dialog to the host assistant. Do not waste the user\'s time. Do not make up invalid tools or functions.',
            other assistants that are available and are outside of your scope are, escalate if they could solve user's problem:
            " 1. Recommendation assistant -> all ai related features like view similar, fbt, buyer product recommendation, or any search using generic terms"
            " 2. Payment assistant -> any payment related query."
            " 3. Customer assistant -> all customer level information or summary in this assistant"
            " 4. Product assistant -> product level information only if user searches product using sku_id."
            " 5. Order assistannt -> order level information. this is the primary order assistant."
            
            """
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)

config = {
    "configurable": {
        "tenant_id": "3442 587242",
        "thread_id": 12579,
    }
}

cart_agent_safe_tools = [add_to_cart,remove_from_cart,cart_info,cart_summary]
cart_agent_sensitive_tools = []
cart_agent_tools = cart_agent_safe_tools + cart_agent_sensitive_tools
cart_agent_runnable = cart_agent_prompt | llm.bind_tools(
    cart_agent_tools + [CompleteOrEscalate], parallel_tool_calls=False
)






#payment_agent

payment_agent_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            this agent deals with everything related to payments, it has 1 tool for that. they are as follows.
            
            1. payment_info - this tool shows the payment information of an order. it requires list of order_id of the order whose payment information is to be fetched.
            "\n\nCurrent user information:\n{user_info}\"
            "\nCurrent time: {time}."
            "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
            ' "CompleteOrEscalate" the dialog to the host assistant. Do not waste the user\'s time. Do not make up invalid tools or functions.',
             other assistants that are available and are outside of your scope are, escalate if they could solve user's problem:
            " 1. Recommendation assistant -> all ai related features like view similar, fbt, buyer product recommendation, or any search using generic terms"
            " 2. Cart assistant -> anything related to cart, like add or remove products from cart, pull cart information or summary, etc."
            " 3. Customer assistant -> all customer level information or summary in this assistant"
            " 4. Product assistant -> product level information only if user searches product using sku_id."
            " 5. Order assistannt -> order level information. this is the primary order assistant."
            """
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)

config = {
    "configurable": {
        "tenant_id": "3442 587242",
        "thread_id": 12579,
    }
}

payment_agent_safe_tools = [payment_info]
payment_agent_sensitive_tools = []
payment_agent_tools = payment_agent_safe_tools + payment_agent_sensitive_tools
payment_agent_runnable = payment_agent_prompt | llm.bind_tools(
    payment_agent_tools + [CompleteOrEscalate], parallel_tool_calls=False
)


#customer_agent

customer_agent_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            this agent deals with everything related to customer summary or details, it has 2 tools for that. they are as follows. for sales related question of a customer like, recent order, order value, use customer_summary. for customer information like address, email contact, call customer_info.
            switch between tools if required, do not keep on calling one tool again and again if it is not helpful, try finding in other tools or escalate.
            1. customer_info - this tool shows the basic customer information like address, email, contact, etc of a customer. it requires either customer name or customer id.
            2. customer_summary -  this tool shows the customer sales summary like total order value, total no of orders, recent order, average order value, etc of a customer. it requires either customer name or customer id. 
            "\n\nCurrent user information:\n{user_info}\"
            "\nCurrent time: {time}."
            "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
            ' "CompleteOrEscalate" the dialog to the host assistant. Do not waste the user\'s time. Do not make up invalid tools or functions.',
             other assistants that are available and are outside of your scope are, escalate if they could solve user's problem:
            " 1. Recommendation assistant -> all ai related features like view similar, fbt, buyer product recommendation, or any search using generic terms"
            " 2. Cart assistant -> anything related to cart, like add or remove products from cart, pull cart information or summary, etc."
            " 3. Payment assistant -> any payment related query."
            " 4. Product assistant -> product level information only if user searches product using sku_id."
            " 5. Order assistannt -> order level information. this is the primary order assistant."
            """
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)

config = {
    "configurable": {
        "tenant_id": "3442 587242",
        "thread_id": 12579,
    }
}

customer_agent_safe_tools = [customer_info,customer_summary]
customer_agent_sensitive_tools = []
customer_agent_tools = customer_agent_safe_tools + customer_agent_sensitive_tools
customer_agent_runnable = customer_agent_prompt | llm.bind_tools(
    customer_agent_tools + [CompleteOrEscalate], parallel_tool_calls=False
)





#product_agent

product_agent_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            this agent deals with everything related to product, it has 1 tool for that. they are as follows.
            
            1. product_info - this tool shows the product information. it requires sku_id of the product whose information is to be shown.
            "\n\nCurrent user information:\n{user_info}\"
            "\nCurrent time: {time}."
            "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
            ' "CompleteOrEscalate" the dialog to the host assistant. Do not waste the user\'s time. Do not make up invalid tools or functions.',
             other assistants that are available and are outside of your scope are, escalate if they could solve user's problem:
            " 1. Recommendation assistant -> all ai related features like view similar, fbt, buyer product recommendation, or any search using generic terms"
            " 2. Cart assistant -> anything related to cart, like add or remove products from cart, pull cart information or summary, etc."
            " 3. Payment assistant -> any payment related query."
            " 4. Customer assistant -> all customer level information or summary in this assistant"
            " 5. Order assistant -> order level information. this is the primary order assistant."
            """
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)


product_agent_safe_tools = [product_info]
product_agent_sensitive_tools = []
product_agent_tools = product_agent_safe_tools + product_agent_sensitive_tools
product_agent_runnable = product_agent_prompt | llm.bind_tools(
    product_agent_tools + [CompleteOrEscalate], parallel_tool_calls=False
)


#order_agent

order_agent_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            this agent deals with everything related to order, Note that order and cart are two different features, do not do the action on order, if user has asked to perform action on cart or vice versa. there is a separate assistant for cart related features or queries. 
            this asssistant has 4 tools for that. they are as follows.
            
            1. order_info - this tool shows the order information like products in it, quantity, shipping address, total order value, status etc. it requires order_id of the order whose information is to be shown.
            2. order_summary - this tool shows the summary of the order like total number of items in it, total order value, etc. it requires order_id as paramater.
            3. create_order - this tool creates an order. it requires customer_id or customer_name and list of SKU ID of products to be added in cart.
            4. shipment_info - this tool shows the shipment information of an order. it requires order_id as parameter.
            "\n\nCurrent user information:\n{user_info}\"
            "\nCurrent time: {time}."
            "\n\nIf the user needs help, and none of your tools are appropriate for it, then"
            ' "CompleteOrEscalate" the dialog to the host assistant. Do not waste the user\'s time. Do not make up invalid tools or functions.',
             other assistants that are available and are outside of your scope are, escalate if they could solve user's problem:
            " 1. Recommendation assistant -> all ai related features like view similar, fbt, buyer product recommendation, or any search using generic terms"
            " 2. Cart assistant -> anything related to cart, like add or remove products from cart, pull cart information or summary, etc."
            " 3. Payment assistant -> any payment related query."
            " 4. Customer assistant -> all customer level information or summary in this assistant"
            " 5. Product assistant -> product level information only if user searches product using sku_id."
      
            """
        ),
        ("placeholder", "{messages}"),
    ]
).partial(time=datetime.now)


order_agent_safe_tools = [order_info,order_summary,create_order,shipment_info]
order_agent_sensitive_tools = []
order_agent_tools = order_agent_safe_tools + order_agent_sensitive_tools
order_agent_runnable = order_agent_prompt | llm.bind_tools(
    order_agent_tools + [CompleteOrEscalate], parallel_tool_calls=False
)



class ToRecommendationAssistant(BaseModel):
    """Transfers work to a specialized assistant to handle AI related features."""

    sku_id: Optional[str] = Field(
        description="The SKU ID of the product whose similar products or frequently bought products are to be shown. this is required only for view_similar or frequently bought together feature"
    )
    buyer_id: Optional[str] = Field(
        description="The buyer_id of the customer for whom recommended products are to be shown. this is required only for showing product recommendations for a particular buyer"
    )
    buyer_name: Optional[str] = Field(
        description="The buyer name of the customer for whom recommended products are to be shown. this is required only for showing product recommendations for a particular buyer"
    )
    term: Optional[str] = Field(
        description="The term through which user wants to search for a product. this is required only for smart search feature"
    )
    request: Optional[str] = Field(
        default=None,
        description="Any additional information or requests from the user regarding the ai related features.",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "sku_id": "AFOUYGO78",
                "buyer_id":"",
                "buyer_name":"",
                "term":"bright portrait",
                "request": "Show me the name of second similar product",
            }
        }


class ToCartAssistant(BaseModel):
    """Transfers work to a specialized assistant to handle cart related features."""

    sku_ids: Optional[List[str]] = Field(
        description="The list of SKU ID of the products which are to be added to or removed from the cart. this is required only for add_to_cart and remove_from_cart tools"
    )
    buyer_id: Optional[str] = Field(
        description="The buyer_id of the customer whose cart is being fetched or shown." 
    )
    buyer_name: Optional[str] = Field(
        description="The buyer name of the customer customer whose cart is being fetched or shown."
    )
    request: Optional[str] = Field(
        default=None,
        description="Any additional information or requests from the user regarding cart",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "sku_ids": ["DADOUGOFA","AFGYIG","1379TVG"] ,
                "buyer_id":"",
                "buyer_name":"JOHN",
                "request": "show me cart details of the customer having name Ayush",
            }
        }





class ToPaymentAssistant(BaseModel):
    """Transfers work to a specialized assistant to handle payment related features or queries."""

    order_id: str = Field(
        description="The order_id of the order whose payment informations is to be fetched."
    )
    
    request: Optional[str] = Field(
        default=None,
        description="Any additional information or requests from the user regarding the payments.",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "order_id": "FDOAUGOUY",
                "request": "show me payment details of the order with order ID ALOHUGOUY",
            }
        }

class ToCustomerAssistant(BaseModel):
    """Transfers work to a specialized assistant to handle customer related features or queries."""

    customer_id: Optional[str] = Field(
        description="The id of the customer whose information or summary is to be fetched."
    )

    customer_name: Optional[str] = Field(
        description="The name of the customer whose information or summary is to be fetched."
    )

    
    request: Optional[str] = Field(
        default=None,
        description="Any additional information or requests from the user regarding customer.",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "customer_id": "FDOAUGOUY",
                "customer_name":"Ayush",
                "request": "show me customer details of the customer named Raghu",
            }
        }



class ToProductAssistant(BaseModel):
    """Transfers work to a specialized assistant to handle product related features or queries."""

    sku_id: str = Field(
        description="The id of the product whose information is to be shown."
    )
    
    request: Optional[str] = Field(
        default=None,
        description="Any additional information or requests from the user regarding the products.",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "sku_id": "FDOAUGOUY",
                "request": "tell me about the product having id AIYDFGOIH",
            }
        }



class ToOrderAssistant(BaseModel):
    """Transfers work to a specialized assistant to handle order related features or queries."""

    sku_ids: Optional[List[str]] = Field(
        description="The list of SKU ID of the products which are to be included in the order for creating an order. this is required only for create_order tool"
    )
    
    order_id: Optional[str] = Field(
        description="The id of the order whose information is to be shown."
    )

    customer_id: Optional[str] =Field(
        description ="The id of the customer for whom order needs to be created."

    )

    customer_name : Optional[str] = Field(
        description = "The name of the customer for whom order need to be created."
    )
    request: Optional[str] = Field(
        default=None,
        description="Any additional information or requests from the user regarding the orders.",
    )

    class Config:
        json_schema_extra = {
            "example": {
                "sku_ids": "[SKU123,AFOUG8,AFGHKP78]",
                "order_id": "ORD2357",
                "custmer_id": "CUST2368",
                "customer_name":"None",
                "request": "tell me about the order having id ORD5586",
            }
        }



primary_assistant_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            
            "You are a helpful customer support assistant for Wizcommerce. "
            "Wizcommerce is a B2B tech solution for wholesalers and distributors. The customers of wizcommerce are wholesalers are distributers, you will be interacting with someone in that industry."
            "They use Wizcommerce to sell in a better and efficient way to their customers. Their customers are retailers."
            "Your primary role is to answer the customer queries, and perform any actions which customer wants to perform."
            "Try calling tools with the parameters you already have, if no paramter is there, then ask only for parameter which is required for that task only, you must ask for every parameter."
            "delegate the task to the appropriate specialized assistant by invoking the corresponding tool. You are not able to make these types of changes yourself."
            "You have majorily following assistants:"
            " 1. Recommendation assistant -> all ai related features like view similar, fbt, buyer product recommendation, or any search using generic terms"
            " 2. Cart assistant -> anything related to cart, like add or remove products from cart, pull cart information or summary, etc."
            " 3. Payment assistant -> any payment related query."
            " 4. Customer assistant -> all customer level information or summary in this assistant"
            " 5. Product assistant -> product level information only if user searches product using sku_id."
            " 6. Order assistannt -> order level information. this is the primary order assistant."
            "When you get any message that no tools are available for this action, or i do not have access to this feature, or you are not able to decide which tool to call, you must search in other assistants. all the tools are available, it is just that they are spread over multiple assistants. keep searching each assistant one by one. do not stop at just first guess."
            " Only the specialized assistants are given permission to do this for the user."
            "Customer and buyer are used interchangeably, like customer id is same as buyer id and customer name is same as buyer name. remember this"
            "The user is not aware of the different specialized assistants, so do not mention them; just quietly delegate through function calls. "
            "Provide detailed information to the customer, and always double-check before concluding that information is unavailable. "
            " When searching, be persistent. Expand your query bounds if the first search returns no results. "
            " If a search comes up empty, expand your search before giving up."
            "Cart is different from order. Cart is abandoned cart, while order is order placed."
            
            
            "\n\nCurrent user:\n<User>\n{user_info}\n</User>"
            "\nCurrent time: {time}.",
        ),
        ("placeholder", "{messages}"),

        
    ]
).partial(time=datetime.now)


primary_assistant_tools = [
    fetch_info,
]

assistant_runnable = primary_assistant_prompt | llm.bind_tools(
    primary_assistant_tools
    + [
        ToRecommendationAssistant,
        ToCartAssistant,
        ToPaymentAssistant,
        ToCustomerAssistant,
        ToProductAssistant,
        ToOrderAssistant,
    ], parallel_tool_calls=False
)


def create_entry_node(assistant_name: str, new_dialog_state: str) -> Callable:
    def entry_node(state: State) -> dict:
        tool_call_id = state["messages"][-1].tool_calls[0]["id"]
        return {
            "messages": [
                ToolMessage(
                    content=f"The assistant is now the {assistant_name}. Reflect on the above conversation between the host assistant and the user."
                    f" The user's intent is unsatisfied. Use the provided tools to assist the user. Remember, you are {assistant_name},"
                    """
                    action is not complete until after you have successfully invoked the appropriate tool.
                    If the user changes their mind or needs help for other tasks, call the CompleteOrEscalate function to let the primary host assistant take control.
                    Do not mention who you are - just act as the proxy for the assistant.""",
                    tool_call_id=tool_call_id,
                )
            ],
            "dialog_state": new_dialog_state,
        }

    return entry_node




#graph start

builder = StateGraph(State)
builder.add_node("fetch_info", user_info)
builder.add_edge(START, "fetch_info")


#recommendation assistant

builder.add_node(
    "enter_recommendation_agent",
    create_entry_node("Recommendation Assistant", "recommendation_agent"),
)
builder.add_node("recommendation_agent", Assistant(recommendation_agent_runnable))
builder.add_edge("enter_recommendation_agent", "recommendation_agent")
builder.add_node(
    "recommendation_agent_sensitive_tools",
    create_tool_node_with_fallback(recommendation_agent_sensitive_tools),
)
builder.add_node(
    "recommendation_agent_safe_tools",
    create_tool_node_with_fallback(recommendation_agent_safe_tools),
)

def route_recommendation_agent(
    state: State,
):
    print("route recommendation agent 1 state", state)
    route = tools_condition(state)
    print("route recommendation agent 2 route", route)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    print("route recommendation agent 2 tool_calls", tool_calls)
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "leave_skill"
    safe_toolnames = [t.name for t in recommendation_agent_safe_tools]
    if all(tc["name"] in safe_toolnames for tc in tool_calls):
        return "recommendation_agent_safe_tools"
    return "recommendation_agent_sensitive_tools"



builder.add_edge("recommendation_agent_sensitive_tools", "recommendation_agent")
builder.add_edge("recommendation_agent_safe_tools", "recommendation_agent")
builder.add_conditional_edges(
    "recommendation_agent",
    route_recommendation_agent,
    ["recommendation_agent_sensitive_tools", "recommendation_agent_safe_tools", "leave_skill", END],
)



def pop_dialog_state(state: State) -> dict:
    """Pop the dialog stack and return to the main assistant.

    This lets the full graph explicitly track the dialog flow and delegate control
    to specific sub-graphs.
    """
    messages = []
    if state["messages"][-1].tool_calls:
        # Note: Doesn't currently handle the edge case where the llm performs parallel tool calls
        messages.append(
            ToolMessage(
                content="Resuming dialog with the host assistant. Please reflect on the past conversation and assist the user as needed.",
                tool_call_id=state["messages"][-1].tool_calls[0]["id"],
            )
        )
    return {
        "dialog_state": "pop",
        "messages": messages,
    }


builder.add_node("leave_skill", pop_dialog_state)
builder.add_edge("leave_skill", "primary_assistant")


# cart assistant

builder.add_node(
    "enter_cart_agent",
    create_entry_node("Cart Assistant", "cart_agent"),
)
builder.add_node("cart_agent", Assistant(cart_agent_runnable))
builder.add_edge("enter_cart_agent", "cart_agent")
builder.add_node(
    "cart_agent_safe_tools",
    create_tool_node_with_fallback(cart_agent_safe_tools),
)
builder.add_node(
    "cart_agent_sensitive_tools",
    create_tool_node_with_fallback(cart_agent_sensitive_tools),
)


def route_cart_agent(
    state: State,
):
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "leave_skill"
    safe_toolnames = [t.name for t in cart_agent_safe_tools]
    if all(tc["name"] in safe_toolnames for tc in tool_calls):
        return "cart_agent_safe_tools"
    return "cart_agent_sensitive_tools"


builder.add_edge("cart_agent_sensitive_tools", "cart_agent")
builder.add_edge("cart_agent_safe_tools", "cart_agent")
builder.add_conditional_edges(
    "cart_agent",
    route_cart_agent,
    [
        "cart_agent_safe_tools",
        "cart_agent_sensitive_tools",
        "leave_skill",
        END,
    ],
)

# Payment assistant

builder.add_node(
    "enter_payment_agent",
    create_entry_node("Payment Assistant", "payment_agent"),
)
builder.add_node("payment_agent", Assistant(payment_agent_runnable))
builder.add_edge("enter_payment_agent", "payment_agent")
builder.add_node(
    "payment_agent_safe_tools",
    create_tool_node_with_fallback(payment_agent_safe_tools),
)
builder.add_node(
    "payment_agent_sensitive_tools",
    create_tool_node_with_fallback(payment_agent_sensitive_tools),
)


def route_payment_agent(
    state: State,
):
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "leave_skill"
    safe_toolnames = [t.name for t in payment_agent_safe_tools]
    if all(tc["name"] in safe_toolnames for tc in tool_calls):
        return "payment_agent_safe_tools"
    return "payment_agent_sensitive_tools"


builder.add_edge("payment_agent_sensitive_tools", "payment_agent")
builder.add_edge("payment_agent_safe_tools", "payment_agent")
builder.add_conditional_edges(
    "payment_agent",
    route_payment_agent,
    [
        "payment_agent_safe_tools",
        "payment_agent_sensitive_tools",
        "leave_skill",
        END,
    ],
)


# Customer assistant

builder.add_node(
    "enter_customer_agent",
    create_entry_node("Customer Assistant", "customer_agent"),
)
builder.add_node("customer_agent", Assistant(customer_agent_runnable))
builder.add_edge("enter_customer_agent", "customer_agent")
builder.add_node(
    "customer_agent_safe_tools",
    create_tool_node_with_fallback(customer_agent_safe_tools),
)
builder.add_node(
    "customer_agent_sensitive_tools",
    create_tool_node_with_fallback(customer_agent_sensitive_tools),
)


def route_customer_agent(
    state: State,
):
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "leave_skill"
    safe_toolnames = [t.name for t in customer_agent_safe_tools]
    if all(tc["name"] in safe_toolnames for tc in tool_calls):
        return "customer_agent_safe_tools"
    return "customer_agent_sensitive_tools"


builder.add_edge("customer_agent_sensitive_tools", "customer_agent")
builder.add_edge("customer_agent_safe_tools", "customer_agent")
builder.add_conditional_edges(
    "customer_agent",
    route_customer_agent,
    [
        "customer_agent_safe_tools",
        "customer_agent_sensitive_tools",
        "leave_skill",
        END,
    ],
)


# Product assistant

builder.add_node(
    "enter_product_agent",
    create_entry_node("Product Assistant", "product_agent"),
)
builder.add_node("product_agent", Assistant(product_agent_runnable))
builder.add_edge("enter_product_agent", "product_agent")
builder.add_node(
    "product_agent_safe_tools",
    create_tool_node_with_fallback(product_agent_safe_tools),
)
builder.add_node(
    "product_agent_sensitive_tools",
    create_tool_node_with_fallback(product_agent_sensitive_tools),
)


def route_product_agent(
    state: State,
):
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "leave_skill"
    safe_toolnames = [t.name for t in product_agent_safe_tools]
    if all(tc["name"] in safe_toolnames for tc in tool_calls):
        return "product_agent_safe_tools"
    return "product_agent_sensitive_tools"


builder.add_edge("product_agent_sensitive_tools", "product_agent")
builder.add_edge("product_agent_safe_tools", "product_agent")
builder.add_conditional_edges(
    "product_agent",
    route_product_agent,
    [
        "product_agent_safe_tools",
        "product_agent_sensitive_tools",
        "leave_skill",
        END,
    ],
)


# Order assistant

builder.add_node(
    "enter_order_agent",
    create_entry_node("Order Assistant", "order_agent"),
)
builder.add_node("order_agent", Assistant(order_agent_runnable))
builder.add_edge("enter_order_agent", "order_agent")
builder.add_node(
    "order_agent_safe_tools",
    create_tool_node_with_fallback(order_agent_safe_tools),
)
builder.add_node(
    "order_agent_sensitive_tools",
    create_tool_node_with_fallback(order_agent_sensitive_tools),
)


def route_order_agent(
    state: State,
):
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    did_cancel = any(tc["name"] == CompleteOrEscalate.__name__ for tc in tool_calls)
    if did_cancel:
        return "leave_skill"
    safe_toolnames = [t.name for t in order_agent_safe_tools]
    if all(tc["name"] in safe_toolnames for tc in tool_calls):
        return "order_agent_safe_tools"
    return "order_agent_sensitive_tools"


builder.add_edge("order_agent_sensitive_tools", "order_agent")
builder.add_edge("order_agent_safe_tools", "order_agent")
builder.add_conditional_edges(
    "order_agent",
    route_order_agent,
    [
        "order_agent_safe_tools",
        "order_agent_sensitive_tools",
        "leave_skill",
        END,
    ],
)


# Primary assistant
builder.add_node("primary_assistant", Assistant(assistant_runnable))
builder.add_node(
    "primary_assistant_tools", create_tool_node_with_fallback(primary_assistant_tools)
)


def route_primary_assistant(
    state: State,
):
    route = tools_condition(state)
    if route == END:
        return END
    tool_calls = state["messages"][-1].tool_calls
    if tool_calls:
        if tool_calls[0]["name"] == ToRecommendationAssistant.__name__:
            return "enter_recommendation_agent"
        elif tool_calls[0]["name"] == ToCartAssistant.__name__:
            return "enter_cart_agent"
        elif tool_calls[0]["name"] == ToPaymentAssistant.__name__:
            return "enter_payment_agent"
        elif tool_calls[0]["name"] == ToCustomerAssistant.__name__:
            return "enter_customer_agent"
        elif tool_calls[0]["name"] == ToProductAssistant.__name__:
            return "enter_product_agent"
        elif tool_calls[0]["name"] == ToOrderAssistant.__name__:
            return "enter_order_agent"
        
        """
        elif tool_calls[0]["name"] == ToGetSummaryAssistant.__name__:
            return "enter_get_summary"
        elif tool_calls[0]["name"] == ToShipmentInfoAssistant.__name__:
            return "enter_shipment_info"
        elif tool_calls[0]["name"] == ToPaymentInfoAssistant.__name__:
            return "enter_payment_info"
        elif tool_calls[0]["name"] == ToAddToCartAssistant.__name__:
            return "enter_add_to_cart"
        """
        return "primary_assistant_tools"
    raise ValueError("Invalid route")


# The assistant can route to one of the delegated assistants,
# directly use a tool, or directly respond to the user
builder.add_conditional_edges(
    "primary_assistant",
    route_primary_assistant,
    [
        "enter_recommendation_agent",
        "enter_cart_agent",
        "enter_payment_agent",
        "enter_customer_agent",
        "enter_product_agent",
        "enter_order_agent",
        "primary_assistant_tools",
        END,
    ],
)
builder.add_edge("primary_assistant_tools", "primary_assistant")


# Each delegated workflow can directly respond to the user
# When the user responds, we want to return to the currently active workflow
# def route_to_workflow(
#     state: State,
# ) -> Literal[
#     "primary_assistant",
#     "recommendation_agent",
#     "cart_agent",
#     "payment_agent",
#     "customer_agent",
#     "product_agent",
#     "order_agent",
    
# ]:
#     """If we are in a delegated state, route directly to the appropriate assistant."""
#     dialog_state = state.get("dialog_state")
#     print("bottom",dialog_state)
#     if not dialog_state:
#         return "primary_assistant"
#     return dialog_state[-1]

def route_to_workflow(
    state: State,
) -> Literal[
    "primary_assistant",
    "recommendation_agent",
    "cart_agent",
    "payment_agent",
    "customer_agent",
    "product_agent",
    "order_agent",
    
]:
    """If we are in a delegated state, route directly to the appropriate assistant."""
    dialog_state = state.get("dialog_state")
    if isinstance(dialog_state, list) and any(isinstance(item, list) for item in dialog_state):
        print("Error: Nested dialog_state detected!")
    dialog_state = [item for sublist in dialog_state for item in (sublist if isinstance(sublist, list) else [sublist])]
    state["dialog_state"] = dialog_state
    print("bottom",dialog_state)
    print("state bottom", state.get("messages"))
    if not dialog_state:
        return "primary_assistant"
    return dialog_state[-1]




builder.add_conditional_edges("fetch_info", route_to_workflow)

# Compile graph
memory = MemorySaver()
master_graph = builder.compile(
    checkpointer=memory,
    # Let the user approve or deny the use of sensitive tools
    interrupt_before=[
    ],
)

# print('hehe')