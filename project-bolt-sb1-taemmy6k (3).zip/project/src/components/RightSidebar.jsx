import { useState, useCallback, useEffect } from 'react';
import { Box, Paper, Typography, IconButton, Tabs, Tab, Collapse } from '@mui/material';
import { ChevronDown, ChevronRight, RefreshCw, Square, Bug, Info } from 'lucide-react';
import { useStore } from '../store/flowStore';

function ContextSection({ title, timestamp, children, onRefresh }) {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <Box sx={{ mb: 2 }}>
      <Box 
        sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          bgcolor: 'grey.100',
          py: 0.5,
          px: 1,
          cursor: 'pointer'
        }}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? (
          <ChevronDown size={16} style={{ marginRight: 4 }} />
        ) : (
          <ChevronRight size={16} style={{ marginRight: 4 }} />
        )}
        <Typography variant="body2" sx={{ flex: 1, fontWeight: 500 }}>
          {title}
        </Typography>
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          <IconButton size="small" onClick={(e) => {
            e.stopPropagation();
            onRefresh?.();
          }}>
            <RefreshCw size={14} />
          </IconButton>
          <IconButton size="small" onClick={(e) => {
            e.stopPropagation();
          }}>
            <Square size={14} />
          </IconButton>
        </Box>
      </Box>
      <Collapse in={isOpen}>
        <Box sx={{ p: 2, color: 'text.secondary' }}>
          {children || (
            <Typography variant="body2" sx={{ fontStyle: 'italic' }}>
              empty
            </Typography>
          )}
          {timestamp && (
            <Typography variant="caption" sx={{ display: 'block', textAlign: 'right', mt: 1 }}>
              {new Date(timestamp).toLocaleString()}
            </Typography>
          )}
        </Box>
      </Collapse>
    </Box>
  );
}

function DebugSection({ title, messages = [] }) {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <Box sx={{ mb: 2 }}>
      <Box 
        sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          bgcolor: 'grey.100',
          py: 0.5,
          px: 1,
          cursor: 'pointer'
        }}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? (
          <ChevronDown size={16} style={{ marginRight: 4 }} />
        ) : (
          <ChevronRight size={16} style={{ marginRight: 4 }} />
        )}
        <Typography variant="body2" sx={{ flex: 1, fontWeight: 500 }}>
          {title}
        </Typography>
        <Typography variant="caption" sx={{ color: 'text.secondary', mr: 1 }}>
          {messages.length} messages
        </Typography>
        <IconButton size="small" onClick={(e) => {
          e.stopPropagation();
        }}>
          <Square size={14} />
        </IconButton>
      </Box>
      <Collapse in={isOpen}>
        <Box sx={{ 
          maxHeight: 300, 
          overflowY: 'auto',
          borderBottom: 1,
          borderColor: 'divider'
        }}>
          {messages.map((msg, index) => (
            <Box 
              key={index}
              sx={{ 
                p: 1.5,
                borderBottom: '1px solid',
                borderColor: 'divider',
                '&:last-child': { borderBottom: 0 },
                '&:hover': { bgcolor: 'action.hover' }
              }}
            >
              <Typography variant="caption" sx={{ color: 'text.secondary', display: 'block', mb: 0.5 }}>
                {new Date(msg.timestamp).toLocaleTimeString()}
              </Typography>
              <Typography variant="body2" sx={{ 
                color: msg.type === 'error' ? 'error.main' : 'text.primary',
                fontFamily: 'monospace',
                whiteSpace: 'pre-wrap'
              }}>
                {msg.content}
              </Typography>
            </Box>
          ))}
        </Box>
      </Collapse>
    </Box>
  );
}

export default function RightSidebar() {
  const { isRightSidebarOpen, rightSidebarWidth, setRightSidebarWidth } = useStore();
  const [isResizing, setIsResizing] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  // Mock data for demonstration
  const debugMessages = [
    { timestamp: Date.now() - 5000, type: 'info', content: 'Workflow started' },
    { timestamp: Date.now() - 4000, type: 'info', content: 'Processing node "Transform Data"' },
    { timestamp: Date.now() - 3000, type: 'error', content: 'Error in node "API Call":\nFailed to fetch data' },
    { timestamp: Date.now() - 2000, type: 'info', content: 'Retrying API call...' },
    { timestamp: Date.now() - 1000, type: 'info', content: 'Workflow completed' },
  ];

  const handleMouseMove = useCallback((e) => {
    if (!isResizing) return;
    const width = window.innerWidth - e.clientX;
    setRightSidebarWidth(width);
  }, [isResizing, setRightSidebarWidth]);

  const handleMouseUp = useCallback(() => {
    setIsResizing(false);
  }, []);

  useEffect(() => {
    if (isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    } else {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing, handleMouseMove, handleMouseUp]);

  return (
    <Paper 
      elevation={3}
      sx={{
        width: rightSidebarWidth,
        height: '100%',
        overflowY: 'auto',
        borderRadius: 0,
        borderLeft: 1,
        borderColor: 'divider',
        position: 'relative',
        transition: isResizing ? 'none' : 'width 0.3s ease',
      }}
    >
      {/* Resize Handle */}
      <Box
        onMouseDown={() => setIsResizing(true)}
        sx={{
          position: 'absolute',
          left: -4,
          top: 0,
          width: 8,
          height: '100%',
          cursor: 'col-resize',
          zIndex: 2000,
          '&::after': {
            content: '""',
            position: 'absolute',
            left: 4,
            top: 0,
            width: '1px',
            height: '100%',
            backgroundColor: 'divider',
          },
          '&:hover': {
            '&::after': {
              width: '2px',
              backgroundColor: 'primary.main',
            },
          },
          ...(isResizing && {
            '&::after': {
              width: '2px',
              backgroundColor: 'primary.main',
            },
          }),
        }}
      />

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs 
          value={activeTab} 
          onChange={(_, newValue) => setActiveTab(newValue)}
          sx={{
            minHeight: 36,
            '& .MuiTab-root': {
              minHeight: 36,
              py: 0.5,
            },
          }}
        >
          <Tab 
            icon={<Info size={16} />} 
            iconPosition="start" 
            label="Context" 
            sx={{ 
              textTransform: 'none',
              fontSize: '0.875rem',
            }} 
          />
          <Tab 
            icon={<Bug size={16} />} 
            iconPosition="start" 
            label="Debug" 
            sx={{ 
              textTransform: 'none',
              fontSize: '0.875rem',
            }} 
          />
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ display: activeTab === 0 ? 'block' : 'none', p: 1 }}>
        <ContextSection 
          title="Node" 
          timestamp={Date.now()}
        />

        <ContextSection 
          title="Flow" 
          timestamp={Date.now()}
        />

        <ContextSection 
          title="Global" 
          timestamp={Date.now()}
        />
      </Box>

      <Box sx={{ display: activeTab === 1 ? 'block' : 'none', p: 1 }}>
        <DebugSection 
          title="Messages" 
          messages={debugMessages}
        />
      </Box>
    </Paper>
  );
}