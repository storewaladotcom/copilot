import { useState } from 'react';
import { Box, Typography, IconButton, TextField, Button, Tabs, Tab, Switch, FormControlLabel, Paper, InputAdornment } from '@mui/material';
import { X, Settings, FileText, RotateCw, Copy, Timer, Wrench, Package } from 'lucide-react';
import { useStore } from '../store/flowStore';
import Editor from "@monaco-editor/react";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      style={{ height: '100%', display: value === index ? 'block' : 'none' }}
      {...other}
    >
      {value === index && children}
    </div>
  );
}

export default function ConfigDrawer() {
  const { selectedNode, updateNodeData, closeConfigDrawer, deleteNode, isRightSidebarOpen, rightSidebarWidth } = useStore();
  const [tabValue, setTabValue] = useState(0);
  const [enabled, setEnabled] = useState(true);
  const [outputs, setOutputs] = useState(1);
  const [timeout, setTimeout] = useState(0);
  const [modules, setModules] = useState([
    { name: 'module', importAs: 'variable' }
  ]);

  if (!selectedNode) return null;

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleDelete = () => {
    if (selectedNode) {
      deleteNode(selectedNode.id);
      closeConfigDrawer();
    }
  };

  const handleNameChange = (event) => {
    updateNodeData(selectedNode.id, {
      ...selectedNode.data,
      label: event.target.value,
    });
  };

  const handleAddModule = () => {
    setModules([...modules, { name: '', importAs: '' }]);
  };

  const handleRemoveModule = (index) => {
    setModules(modules.filter((_, i) => i !== index));
  };

  const handleModuleChange = (index, field, value) => {
    const newModules = [...modules];
    newModules[index][field] = value;
    setModules(newModules);
  };

  const renderSetupTab = () => (
    <Box sx={{ p: 2, height: '100%', overflow: 'auto' }}>
      {/* Outputs Section */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Wrench size={20} style={{ marginRight: 8 }} />
          <Typography variant="subtitle1">Outputs</Typography>
        </Box>
        <TextField
          type="number"
          size="small"
          value={outputs}
          onChange={(e) => setOutputs(Number(e.target.value))}
          InputProps={{
            inputProps: { min: 1 },
          }}
          sx={{ width: 100 }}
        />
      </Box>

      {/* Timeout Section */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Timer size={20} style={{ marginRight: 8 }} />
          <Typography variant="subtitle1">Timeout</Typography>
        </Box>
        <TextField
          type="number"
          size="small"
          value={timeout}
          onChange={(e) => setTimeout(Number(e.target.value))}
          InputProps={{
            inputProps: { min: 0 },
          }}
          sx={{ width: 100 }}
        />
      </Box>

      {/* Modules Section */}
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Package size={20} style={{ marginRight: 8 }} />
          <Typography variant="subtitle1">Modules</Typography>
        </Box>
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Module name</Typography>
            <Typography variant="subtitle2">Import as</Typography>
          </Box>
          {modules.map((module, index) => (
            <Box key={index} sx={{ display: 'flex', gap: 2, mb: 2 }}>
              <TextField
                size="small"
                fullWidth
                value={module.name}
                onChange={(e) => handleModuleChange(index, 'name', e.target.value)}
                sx={{ flex: 1 }}
              />
              <TextField
                size="small"
                fullWidth
                value={module.importAs}
                onChange={(e) => handleModuleChange(index, 'importAs', e.target.value)}
                sx={{ flex: 1 }}
              />
              <IconButton 
                size="small" 
                onClick={() => handleRemoveModule(index)}
                sx={{ 
                  '&:hover': { 
                    backgroundColor: 'error.light',
                    color: 'error.contrastText'
                  }
                }}
              >
                <X size={16} />
              </IconButton>
            </Box>
          ))}
          <Button 
            variant="outlined" 
            size="small" 
            onClick={handleAddModule}
            sx={{ mt: 1 }}
          >
            + add
          </Button>
        </Paper>
      </Box>
    </Box>
  );

  const drawerWidth = 600;

  return (
    <Box
      sx={{
        position: 'fixed',
        top: 48,
        right: isRightSidebarOpen ? rightSidebarWidth : 0,
        width: drawerWidth,
        height: 'calc(100vh - 48px)',
        backgroundColor: 'background.paper',
        boxShadow: '-4px 0 8px rgba(0, 0, 0, 0.1)',
        transform: `translateX(${selectedNode ? '0' : '100%'})`,
        transition: 'transform 0.3s ease-in-out',
        zIndex: 1100,
        display: 'flex',
        flexDirection: 'column',
        borderLeft: 1,
        borderColor: 'divider',
      }}
    >
      {/* Header */}
      <Box sx={{ 
        p: 2, 
        borderBottom: 1, 
        borderColor: 'divider',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="h6">Edit function node</Typography>
        <Box>
          <Button 
            variant="outlined" 
            color="error" 
            onClick={handleDelete}
            sx={{ mr: 1 }}
          >
            Delete
          </Button>
          <Button 
            variant="outlined" 
            onClick={closeConfigDrawer}
            sx={{ mr: 1 }}
          >
            Cancel
          </Button>
          <Button 
            variant="contained" 
            color="primary"
            onClick={closeConfigDrawer}
          >
            Done
          </Button>
        </Box>
      </Box>

      {/* Properties Section */}
      <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Settings size={20} style={{ marginRight: 8 }} />
          <Typography variant="subtitle1">Properties</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <IconButton size="small">
            <Settings size={20} />
          </IconButton>
          <IconButton size="small">
            <FileText size={20} />
          </IconButton>
          <IconButton size="small">
            <RotateCw size={20} />
          </IconButton>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Typography>Name</Typography>
          <TextField
            size="small"
            value={selectedNode.data.label}
            onChange={handleNameChange}
            fullWidth
          />
          <IconButton size="small">
            <Copy size={20} />
          </IconButton>
        </Box>
      </Box>

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Setup" />
          <Tab label="On Start" />
          <Tab label="On Message" />
          <Tab label="On Stop" />
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ flexGrow: 1, overflow: 'hidden', position: 'relative' }}>
        <TabPanel value={tabValue} index={0}>
          {renderSetupTab()}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <Box sx={{ position: 'absolute', top: 0, right: 0, bottom: 0, left: 0 }}>
            <Editor
              height="100%"
              defaultLanguage="javascript"
              defaultValue="// On Start code here"
              theme="vs-light"
              options={{
                minimap: { enabled: false },
                lineNumbers: 'on',
                glyphMargin: false,
                folding: true,
                lineDecorationsWidth: 0,
                lineNumbersMinChars: 3,
              }}
            />
          </Box>
        </TabPanel>
        <TabPanel value={tabValue} index={2}>
          <Box sx={{ position: 'absolute', top: 0, right: 0, bottom: 0, left: 0 }}>
            <Editor
              height="100%"
              defaultLanguage="javascript"
              defaultValue="// On Message code here"
              theme="vs-light"
              options={{
                minimap: { enabled: false },
                lineNumbers: 'on',
                glyphMargin: false,
                folding: true,
                lineDecorationsWidth: 0,
                lineNumbersMinChars: 3,
              }}
            />
          </Box>
        </TabPanel>
        <TabPanel value={tabValue} index={3}>
          <Box sx={{ position: 'absolute', top: 0, right: 0, bottom: 0, left: 0 }}>
            <Editor
              height="100%"
              defaultLanguage="javascript"
              defaultValue="// On Stop code here"
              theme="vs-light"
              options={{
                minimap: { enabled: false },
                lineNumbers: 'on',
                glyphMargin: false,
                folding: true,
                lineDecorationsWidth: 0,
                lineNumbersMinChars: 3,
              }}
            />
          </Box>
        </TabPanel>
      </Box>

      {/* Footer */}
      <Box sx={{ 
        p: 1, 
        borderTop: 1, 
        borderColor: 'divider',
        display: 'flex',
        alignItems: 'center'
      }}>
        <IconButton size="small">
          <FileText size={20} />
        </IconButton>
        <FormControlLabel
          control={
            <Switch
              checked={enabled}
              onChange={(e) => setEnabled(e.target.checked)}
              size="small"
            />
          }
          label="Enabled"
        />
      </Box>
    </Box>
  );
}