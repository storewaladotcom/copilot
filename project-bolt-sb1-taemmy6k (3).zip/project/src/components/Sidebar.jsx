import { useState } from 'react';
import { Box, Paper, Typography, List, ListItemButton, TextField, Collapse, Tooltip } from '@mui/material';
import { Settings, Database, FunctionSquare, MessageSquare, Globe, Wifi, Image, ChevronDown, ChevronRight } from 'lucide-react';
import { useStore } from '../store/flowStore';

const nodeDescriptions = {
  function: 'A JavaScript function that processes messages',
  database: 'Store and retrieve data from a database',
  message: 'Send and receive messages between nodes',
  settings: 'Configure node settings and parameters',
  mqtt_in: 'Subscribe to MQTT topics',
  mqtt_out: 'Publish to MQTT topics',
  http_in: 'Handle incoming HTTP requests',
  http_out: 'Make HTTP requests to external services',
  websocket_in: 'Accept WebSocket connections',
  websocket_out: 'Connect to WebSocket servers',
  image: 'Process and manipulate images',
};

const nodeGroups = [
  {
    name: 'common',
    nodes: [
      { type: 'function', label: 'Function', icon: FunctionSquare, color: '#ffd0a1' },
      { type: 'database', label: 'Database', icon: Database, color: '#87c9ff' },
      { type: 'message', label: 'Message', icon: MessageSquare, color: '#a7e3a7' },
      { type: 'settings', label: 'Settings', icon: Settings, color: '#e2e2e2' },
    ],
  },
  {
    name: 'network',
    nodes: [
      { type: 'mqtt_in', label: 'mqtt in', icon: Wifi, color: '#e8d7f5' },
      { type: 'mqtt_out', label: 'mqtt out', icon: Wifi, color: '#e8d7f5' },
      { type: 'http_in', label: 'http in', icon: Globe, color: '#e3e0b8' },
      { type: 'http_out', label: 'http out', icon: Globe, color: '#e3e0b8' },
      { type: 'websocket_in', label: 'websocket in', icon: Globe, color: '#e3e0b8' },
      { type: 'websocket_out', label: 'websocket out', icon: Globe, color: '#e3e0b8' },
    ],
  },
  {
    name: 'output',
    nodes: [
      { type: 'image', label: 'image', icon: Image, color: '#a7e3a7' },
    ],
  },
];

export default function Sidebar() {
  const [filter, setFilter] = useState('');
  const [openGroups, setOpenGroups] = useState({
    common: true,
    network: true,
    output: true,
  });

  const toggleGroup = (groupName) => {
    setOpenGroups(prev => ({
      ...prev,
      [groupName]: !prev[groupName],
    }));
  };

  const onDragStart = (event, nodeType) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  const filteredGroups = nodeGroups.map(group => ({
    ...group,
    nodes: group.nodes.filter(node => 
      node.label.toLowerCase().includes(filter.toLowerCase()) ||
      node.type.toLowerCase().includes(filter.toLowerCase())
    ),
  })).filter(group => group.nodes.length > 0);

  return (
    <Paper 
      elevation={3}
      sx={{
        width: 240,
        height: '100%',
        overflowY: 'auto',
        borderRadius: 0,
        borderRight: 1,
        borderColor: 'divider',
      }}
    >
      <Box sx={{ p: 1 }}>
        <TextField
          fullWidth
          size="small"
          placeholder="filter nodes"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          sx={{ 
            mb: 1,
            '& .MuiInputBase-root': {
              height: 32,
            },
          }}
        />
        <List sx={{ p: 0 }}>
          {filteredGroups.map((group) => (
            <Box key={group.name}>
              <ListItemButton
                onClick={() => toggleGroup(group.name)}
                sx={{
                  py: 0.5,
                  px: 1,
                  minHeight: 32,
                  '&:hover': {
                    backgroundColor: 'action.hover',
                  },
                }}
              >
                {openGroups[group.name] ? (
                  <ChevronDown size={16} style={{ marginRight: 4 }} />
                ) : (
                  <ChevronRight size={16} style={{ marginRight: 4 }} />
                )}
                <Typography
                  variant="body2"
                  sx={{
                    textTransform: 'lowercase',
                    fontWeight: 500,
                  }}
                >
                  {group.name}
                </Typography>
              </ListItemButton>
              <Collapse in={openGroups[group.name]}>
                <List sx={{ py: 0 }}>
                  {group.nodes.map((node) => {
                    const Icon = node.icon;
                    return (
                      <Tooltip
                        key={node.type}
                        title={nodeDescriptions[node.type]}
                        placement="right"
                        arrow
                        enterDelay={400}
                        sx={{
                          '& .MuiTooltip-tooltip': {
                            backgroundColor: '#333',
                            color: '#fff',
                            fontSize: '0.75rem',
                            padding: '6px 10px',
                            maxWidth: 200,
                          },
                          '& .MuiTooltip-arrow': {
                            color: '#333',
                          },
                        }}
                      >
                        <Box
                          draggable
                          onDragStart={(event) => onDragStart(event, node.type)}
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 1,
                            mx: 1,
                            my: 0.5,
                            px: 1.5,
                            py: 0.75,
                            borderRadius: '4px',
                            backgroundColor: node.color,
                            cursor: 'grab',
                            position: 'relative',
                            minHeight: 28,
                            '&:hover': {
                              filter: 'brightness(0.95)',
                            },
                            '&::before, &::after': {
                              content: '""',
                              position: 'absolute',
                              width: 6,
                              height: 6,
                              backgroundColor: '#999',
                              border: '2px solid white',
                              borderRadius: '50%',
                              boxShadow: '0 0 0 1px rgba(0,0,0,0.15)',
                            },
                            '&::before': {
                              left: -3,
                              top: '50%',
                              transform: 'translateY(-50%)',
                            },
                            '&::after': {
                              right: -3,
                              top: '50%',
                              transform: 'translateY(-50%)',
                            },
                          }}
                        >
                          <Icon size={14} />
                          <Typography
                            variant="body2"
                            sx={{
                              flex: 1,
                              textTransform: 'lowercase',
                              fontSize: '0.8125rem',
                            }}
                          >
                            {node.label}
                          </Typography>
                        </Box>
                      </Tooltip>
                    );
                  })}
                </List>
              </Collapse>
            </Box>
          ))}
        </List>
      </Box>
    </Paper>
  );
}