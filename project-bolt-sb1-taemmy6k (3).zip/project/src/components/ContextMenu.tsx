import { Menu, MenuItem, ListItemIcon, Typography } from '@mui/material';
import { Copy, Scissors, Trash, Trash2, File as FileExport, MousePointer2, Plus, Undo, Redo } from 'lucide-react';

interface ContextMenuProps {
  open: boolean;
  position: { x: number; y: number };
  onClose: () => void;
  onCopy: () => void;
  onCut: () => void;
  onDelete: () => void;
  onDeleteAndReconnect: () => void;
  onExport: () => void;
  onSelectAll: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
}

export default function ContextMenu({
  open,
  position,
  onClose,
  onCopy,
  onCut,
  onDelete,
  onDeleteAndReconnect,
  onExport,
  onSelectAll,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
}: ContextMenuProps) {
  return (
    <Menu
      open={open}
      onClose={onClose}
      anchorReference="anchorPosition"
      anchorPosition={
        position.x && position.y
          ? { top: position.y, left: position.x }
          : undefined
      }
      sx={{
        '& .MuiPaper-root': {
          boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
          minWidth: 220,
        },
      }}
    >
      <MenuItem disabled>
        <Typography variant="body2" color="text.secondary">
          Show action list
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ p
        </Typography>
      </MenuItem>

      <MenuItem disabled>
        <ListItemIcon>
          <Plus size={18} />
        </ListItemIcon>
        <Typography variant="body2">Insert</Typography>
        <Typography variant="body2" sx={{ ml: 'auto' }}>
          ▶
        </Typography>
      </MenuItem>

      <MenuItem disabled>
        <ListItemIcon>
          <MousePointer2 size={18} />
        </ListItemIcon>
        <Typography variant="body2">Node</Typography>
        <Typography variant="body2" sx={{ ml: 'auto' }}>
          ▶
        </Typography>
      </MenuItem>

      <MenuItem disabled>
        <ListItemIcon>
          <MousePointer2 size={18} />
        </ListItemIcon>
        <Typography variant="body2">Group</Typography>
        <Typography variant="body2" sx={{ ml: 'auto' }}>
          ▶
        </Typography>
      </MenuItem>

      <MenuItem
        onClick={onUndo}
        disabled={!canUndo}
        sx={{ borderTop: 1, borderColor: 'divider', mt: 1 }}
      >
        <Typography variant="body2">Undo</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ z
        </Typography>
      </MenuItem>

      <MenuItem onClick={onRedo} disabled={!canRedo}>
        <Typography variant="body2">Redo</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ y
        </Typography>
      </MenuItem>

      <MenuItem onClick={onCut} sx={{ borderTop: 1, borderColor: 'divider', mt: 1 }}>
        <Typography variant="body2">Cut selected nodes</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ x
        </Typography>
      </MenuItem>

      <MenuItem onClick={onCopy}>
        <Typography variant="body2">Copy selected nodes</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ c
        </Typography>
      </MenuItem>

      <MenuItem disabled>
        <Typography variant="body2" color="text.secondary">
          Paste nodes
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ v
        </Typography>
      </MenuItem>

      <MenuItem onClick={onDelete}>
        <Typography variant="body2">Delete selection</Typography>
        <Typography variant="body2" sx={{ ml: 'auto', fontFamily: 'monospace' }}>
          delete
        </Typography>
      </MenuItem>

      <MenuItem onClick={onDeleteAndReconnect}>
        <Typography variant="body2">Delete and reconnect</Typography>
        <Typography variant="body2" sx={{ ml: 'auto', fontFamily: 'monospace' }}>
          ⌘ delete
        </Typography>
      </MenuItem>

      <MenuItem onClick={onExport} sx={{ borderTop: 1, borderColor: 'divider', mt: 1 }}>
        <Typography variant="body2">Export</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ e
        </Typography>
      </MenuItem>

      <MenuItem onClick={onSelectAll}>
        <Typography variant="body2">Select all</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 'auto' }}>
          ⌘ a
        </Typography>
      </MenuItem>
    </Menu>
  );
}