import { Handle, Position } from 'reactflow';
import { Box, Typography, Tooltip, IconButton } from '@mui/material';
import { Settings, Database, FunctionSquare, MessageSquare, Globe, Wifi, Image, MoreHorizontal } from 'lucide-react';

const getNodeColor = (type: string): string => {
  switch (type) {
    case 'function':
      return '#ffd0a1';
    case 'database':
      return '#87c9ff';
    case 'message':
      return '#a7e3a7';
    case 'settings':
      return '#e2e2e2';
    case 'mqtt_in':
    case 'mqtt_out':
      return '#e8d7f5';
    case 'http_in':
    case 'http_out':
    case 'websocket_in':
    case 'websocket_out':
      return '#e3e0b8';
    case 'image':
      return '#a7e3a7';
    default:
      return '#ffffff';
  }
};

const getIcon = (type: string) => {
  switch (type) {
    case 'function':
      return FunctionSquare;
    case 'database':
      return Database;
    case 'message':
      return MessageSquare;
    case 'settings':
      return Settings;
    case 'mqtt_in':
    case 'mqtt_out':
      return Wifi;
    case 'http_in':
    case 'http_out':
    case 'websocket_in':
    case 'websocket_out':
      return Globe;
    case 'image':
      return Image;
    default:
      return FunctionSquare;
  }
};

export type CustomNodeData = {
  label: string;
  type: string;
};

interface CustomNodeProps {
  data: CustomNodeData;
  id: string;
}

export default function CustomNode({ data, id }: CustomNodeProps) {
  const Icon = getIcon(data.type);
  const backgroundColor = getNodeColor(data.type);

  const handleMenuClick = (event: React.MouseEvent) => {
    // Stop event from triggering node selection
    event.stopPropagation();
    
    // Create a custom event that will be handled by the Flow component
    const customEvent = new MouseEvent('contextmenu', {
      bubbles: true,
      clientX: event.clientX,
      clientY: event.clientY
    });
    event.target.dispatchEvent(customEvent);
  };

  const tooltipStyles = {
    '& .MuiTooltip-tooltip': {
      backgroundColor: '#333',
      color: '#fff',
      fontSize: '0.75rem',
      padding: '6px 10px',
      maxWidth: 200,
    },
    '& .MuiTooltip-arrow': {
      color: '#333',
    },
  };

  return (
    <Box
      sx={{
        backgroundColor,
        borderRadius: '3px',
        border: '1px solid rgba(0,0,0,0.1)',
        padding: '0.25rem 0.75rem',
        minWidth: '120px',
        display: 'flex',
        alignItems: 'center',
        gap: 0.75,
        fontSize: '0.75rem',
        color: 'rgba(0,0,0,0.87)',
        boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
        '&:hover': {
          boxShadow: '0 2px 4px rgba(0,0,0,0.15)',
          '& .node-menu': {
            opacity: 1,
          },
        },
        position: 'relative',
        height: '24px',
      }}
    >
      <Icon size={14} />
      <Typography 
        variant="body2" 
        sx={{ 
          fontWeight: 500,
          fontSize: '0.75rem',
          lineHeight: 1,
          userSelect: 'none'
        }}
      >
        {data.label}
      </Typography>

      {/* Menu Icon */}
      <IconButton
        className="node-menu"
        size="small"
        onClick={handleMenuClick}
        sx={{
          position: 'absolute',
          top: -20,
          right: 4,
          padding: '2px',
          backgroundColor: 'white',
          boxShadow: '0 1px 3px rgba(0,0,0,0.12)',
          opacity: 0,
          transition: 'opacity 0.2s ease',
          '&:hover': {
            backgroundColor: 'white',
          },
        }}
      >
        <MoreHorizontal size={14} />
      </IconButton>

      <Handle
        type="target"
        position={Position.Left}
        className="custom-handle"
        style={{ width: 6, height: 6 }}
      />
      {data.type === 'database' ? (
        <>
          <Tooltip
            title="Success output - Triggered when operation succeeds"
            placement="right"
            arrow
            enterDelay={400}
            sx={tooltipStyles}
          >
            <Handle
              type="source"
              position={Position.Right}
              id="success"
              className="custom-handle"
              style={{ top: '30%', width: 6, height: 6 }}
            />
          </Tooltip>
          <Tooltip
            title="Error output - Triggered when operation fails"
            placement="right"
            arrow
            enterDelay={400}
            sx={tooltipStyles}
          >
            <Handle
              type="source"
              position={Position.Right}
              id="error"
              className="custom-handle"
              style={{ top: '70%', width: 6, height: 6 }}
            />
          </Tooltip>
        </>
      ) : (
        <Tooltip
          title="next"
          placement="right"
          arrow
          enterDelay={400}
          sx={tooltipStyles}
        >
          <Handle
            type="source"
            position={Position.Right}
            className="custom-handle"
            style={{ width: 6, height: 6 }}
          />
        </Tooltip>
      )}
    </Box>
  );
}