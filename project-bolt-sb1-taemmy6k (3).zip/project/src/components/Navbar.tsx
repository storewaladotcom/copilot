import { AppBar, Toolbar, Button, Box, Typography } from '@mui/material';
import { Upload } from 'lucide-react';

export default function Navbar() {
  return (
    <AppBar 
      position="absolute" 
      color="default" 
      elevation={0}
      sx={{ 
        borderBottom: '1px solid',
        borderColor: 'divider',
        bgcolor: 'background.paper',
        zIndex: 1200,
      }}
    >
      <Toolbar variant="dense" sx={{ gap: 2 }}>
        <Typography 
          variant="subtitle2" 
          component="div" 
          sx={{ 
            fontWeight: 500,
            color: 'text.primary',
            flexGrow: 1 
          }}
        >
          Flow Designer
        </Typography>
        <Button
          variant="contained"
          size="small"
          startIcon={<Upload size={16} />}
          sx={{ 
            textTransform: 'none',
            fontWeight: 500,
            fontSize: '0.8125rem',
          }}
        >
          Deploy
        </Button>
      </Toolbar>
    </AppBar>
  );
}