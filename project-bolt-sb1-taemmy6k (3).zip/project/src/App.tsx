import { useCallback, useState } from 'react';
import ReactFlow, {
  Background,
  Controls,
  ReactFlowProvider,
  MarkerType,
  useReactFlow,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Box, CssBaseline, ThemeProvider, IconButton, Tooltip, createTheme } from '@mui/material';
import { PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen } from 'lucide-react';
import CustomNode from './components/CustomNode';
import Sidebar from './components/Sidebar';
import RightSidebar from './components/RightSidebar';
import ConfigDrawer from './components/ConfigDrawer';
import ContextMenu from './components/ContextMenu';
import Navbar from './components/Navbar';
import { useStore } from './store/flowStore';

const nodeTypes = {
  custom: CustomNode,
};

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    background: {
      default: '#f8f8f8',
    },
  },
});

let id = 0;
const getId = () => `node_${id++}`;

function Flow() {
  const { 
    nodes, 
    edges, 
    onNodesChange, 
    onEdgesChange, 
    onConnect, 
    addNode,
    deleteNode,
    openConfigDrawer,
    isSidebarOpen,
  } = useStore();

  const [contextMenu, setContextMenu] = useState({
    open: false,
    position: { x: 0, y: 0 },
  });

  const { project } = useReactFlow();

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      
      if (typeof type === 'undefined' || !type) {
        return;
      }

      const position = project({
        x: event.clientX - (isSidebarOpen ? 240 : 0),
        y: event.clientY,
      });

      const newNode = {
        id: getId(),
        type: 'custom',
        position,
        data: { 
          label: type.charAt(0).toUpperCase() + type.slice(1), 
          type,
          config: {} 
        },
      };

      addNode(newNode);
    },
    [addNode, isSidebarOpen, project]
  );

  const onNodeDoubleClick = (_, node) => {
    openConfigDrawer(node);
  };

  const onNodeContextMenu = (event, node) => {
    event.preventDefault();
    
    const x = event.clientX;
    const y = event.clientY;

    setContextMenu({
      open: true,
      position: { x, y },
      nodeId: node.id,
    });
  };

  const closeContextMenu = () => {
    setContextMenu({ ...contextMenu, open: false });
  };

  const handleCopy = () => {
    closeContextMenu();
  };

  const handleCut = () => {
    closeContextMenu();
  };

  const handleDelete = () => {
    if (contextMenu.nodeId) {
      deleteNode(contextMenu.nodeId);
    } else {
      const selectedNodes = nodes.filter(node => node.selected);
      selectedNodes.forEach(node => deleteNode(node.id));
    }
    closeContextMenu();
  };

  const handleDeleteAndReconnect = () => {
    closeContextMenu();
  };

  const handleExport = () => {
    closeContextMenu();
  };

  const handleSelectAll = () => {
    onNodesChange(
      nodes.map(node => ({
        type: 'select',
        id: node.id,
        selected: true,
      }))
    );
    closeContextMenu();
  };

  return (
    <Box sx={{ 
      width: '100%', 
      height: 'calc(100vh - 200px)', // Updated height
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
    }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDragOver={onDragOver}
        onDrop={onDrop}
        onNodeDoubleClick={onNodeDoubleClick}
        onNodeContextMenu={onNodeContextMenu}
        nodeTypes={nodeTypes}
        defaultEdgeOptions={{
          type: 'smoothstep',
          animated: false,
          markerEnd: {
            type: MarkerType.ArrowClosed,
            width: 7,
            height: 7,
            color: '#999',
          },
        }}
        fitView
      >
        <Background />
        <Controls />
      </ReactFlow>
      <ConfigDrawer />
      <ContextMenu
        open={contextMenu.open}
        position={contextMenu.position}
        onClose={closeContextMenu}
        onCopy={handleCopy}
        onCut={handleCut}
        onDelete={handleDelete}
        onDeleteAndReconnect={handleDeleteAndReconnect}
        onExport={handleExport}
        onSelectAll={handleSelectAll}
        canUndo={false}
        canRedo={false}
        onUndo={() => {}}
        onRedo={() => {}}
      />
    </Box>
  );
}

function App() {
  const { isSidebarOpen, isRightSidebarOpen, rightSidebarWidth, toggleSidebar, toggleRightSidebar } = useStore();

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ 
        width: '100vw', 
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}>
        <Navbar />
        
        <Box sx={{ 
          flex: 1,
          display: 'flex',
          position: 'relative',
          overflow: 'hidden',
          height: 'calc(100vh - 200px)', // Updated height
        }}>
          {/* Left Sidebar */}
          <Box sx={{ 
            position: 'absolute',
            left: 0,
            top: 0,
            bottom: 0,
            width: 240,
            transform: isSidebarOpen ? 'none' : 'translateX(-100%)',
            transition: 'transform 0.3s ease',
            zIndex: 10,
          }}>
            <Sidebar />
          </Box>

          {/* Left Sidebar Toggle */}
          <Tooltip 
            title={isSidebarOpen ? "Hide node palette" : "Show node palette"}
            placement="right"
            arrow
          >
            <Box sx={{
              position: 'absolute',
              left: isSidebarOpen ? 240 : 0,
              top: '50%',
              transform: 'translateY(-50%)',
              zIndex: 1000,
              backgroundColor: 'white',
              borderRadius: '0 4px 4px 0',
              boxShadow: 2,
              transition: 'left 0.3s ease',
            }}>
              <IconButton onClick={toggleSidebar} size="small" sx={{ p: 0.5 }}>
                {isSidebarOpen ? <PanelLeftClose size={20} /> : <PanelLeftOpen size={20} />}
              </IconButton>
            </Box>
          </Tooltip>

          {/* Main Content */}
          <Box sx={{ 
            flex: 1,
            position: 'relative',
            ml: isSidebarOpen ? '240px' : 0,
            transition: 'margin 0.3s ease',
            height: 'calc(100vh - 200px)', // Updated height
          }}>
            <ReactFlowProvider>
              <Flow />
            </ReactFlowProvider>
          </Box>

          {/* Right Sidebar */}
          <Box sx={{ 
            position: 'fixed',
            right: 0,
            top: 48,
            bottom: 0,
            width: rightSidebarWidth,
            transform: isRightSidebarOpen ? 'none' : `translateX(${rightSidebarWidth}px)`,
            transition: 'transform 0.3s ease',
            zIndex: 10,
          }}>
            <RightSidebar />
          </Box>

          {/* Right Sidebar Toggle */}
          <Tooltip 
            title={isRightSidebarOpen ? "Hide inspector" : "Show inspector"}
            placement="left"
            arrow
          >
            <Box sx={{
              position: 'fixed',
              right: isRightSidebarOpen ? rightSidebarWidth : 0,
              top: '50%',
              transform: 'translateY(-50%)',
              zIndex: 1000,
              backgroundColor: 'white',
              borderRadius: '4px 0 0 4px',
              boxShadow: 2,
              transition: 'right 0.3s ease',
            }}>
              <IconButton onClick={toggleRightSidebar} size="small" sx={{ p: 0.5 }}>
                {isRightSidebarOpen ? <PanelRightClose size={20} /> : <PanelRightOpen size={20} />}
              </IconButton>
            </Box>
          </Tooltip>
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;