import { useCallback, useState } from 'react';
import ReactFlow, {
  Background,
  Controls,
  ReactFlowProvider,
  MarkerType,
  useReactFlow,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Box, CssBaseline, ThemeProvider, IconButton, Tooltip, createTheme } from '@mui/material';
import { PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen } from 'lucide-react';
import CustomNode from './components/CustomNode';
import Sidebar from './components/Sidebar';
import RightSidebar from './components/RightSidebar';
import ConfigDrawer from './components/ConfigDrawer';
import ContextMenu from './components/ContextMenu';
import Navbar from './components/Navbar';
import { useStore } from './store/flowStore';

const nodeTypes = {
  custom: CustomNode,
};

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    background: {
      default: '#f8f8f8',
    },
  },
});

let id = 0;
const getId = () => `node_${id++}`;

function Flow() {
  const { 
    nodes, 
    edges, 
    onNodesChange, 
    onEdgesChange, 
    onConnect, 
    addNode,
    deleteNode,
    openConfigDrawer,
    isSidebarOpen,
    isRightSidebarOpen,
    rightSidebarWidth,
  } = useStore();

  const [contextMenu, setContextMenu] = useState({
    open: false,
    position: { x: 0, y: 0 },
  });

  const { project } = useReactFlow();

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      
      if (typeof type === 'undefined' || !type) {
        return;
      }

      const position = project({
        x: event.clientX - (isSidebarOpen ? 240 : 0),
        y: event.clientY,
      });

      const newNode = {
        id: getId(),
        type: 'custom',
        position,
        data: { 
          label: type.charAt(0).toUpperCase() + type.slice(1), 
          type,
          config: {} 
        },
      };

      addNode(newNode);
    },
    [addNode, isSidebarOpen, project]
  );

  const onNodeDoubleClick = (_, node) => {
    openConfigDrawer(node);
  };

  const onNodeContextMenu = (event, node) => {
    event.preventDefault();
    
    const x = event.clientX;
    const y = event.clientY;

    setContextMenu({
      open: true,
      position: { x, y },
      nodeId: node.id,
    });
  };

  const closeContextMenu = () => {
    setContextMenu({ ...contextMenu, open: false });
  };

  const handleCopy = () => {
    closeContextMenu();
  };

  const handleCut = () => {
    closeContextMenu();
  };

  const handleDelete = () => {
    if (contextMenu.nodeId) {
      deleteNode(contextMenu.nodeId);
    } else {
      const selectedNodes = nodes.filter(node => node.selected);
      selectedNodes.forEach(node => deleteNode(node.id));
    }
    closeContextMenu();
  };

  const handleDeleteAndReconnect = () => {
    closeContextMenu();
  };

  const handleExport = () => {
    closeContextMenu();
  };

  const handleSelectAll = () => {
    onNodesChange(
      nodes.map(node => ({
        type: 'select',
        id: node.id,
        selected: true,
      }))
    );
    closeContextMenu();
  };

  return (
    <>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDragOver={onDragOver}
        onDrop={onDrop}
        onNodeDoubleClick={onNodeDoubleClick}
        onNodeContextMenu={onNodeContextMenu}
        nodeTypes={nodeTypes}
        defaultEdgeOptions={{
          type: 'smoothstep',
          animated: false,
          markerEnd: {
            type: MarkerType.ArrowClosed,
            width: 7,
            height: 7,
            color: '#999',
          },
        }}
        fitView
      >
        <Background />
        <Controls />
      </ReactFlow>
      <ConfigDrawer />
      <ContextMenu
        open={contextMenu.open}
        position={contextMenu.position}
        onClose={closeContextMenu}
        onCopy={handleCopy}
        onCut={handleCut}
        onDelete={handleDelete}
        onDeleteAndReconnect={handleDeleteAndReconnect}
        onExport={handleExport}
        onSelectAll={handleSelectAll}
        canUndo={false}
        canRedo={false}
        onUndo={() => {}}
        onRedo={() => {}}
      />
    </>
  );
}

function App() {
  const { isSidebarOpen, isRightSidebarOpen, rightSidebarWidth, toggleSidebar, toggleRightSidebar } = useStore();

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ 
        width: '100vw', 
        height: '100vh', 
        display: 'flex',
        bgcolor: 'background.default',
        position: 'relative',
      }}>
        <Navbar />
        
        {/* Left sidebar toggle */}
        <Tooltip 
          title={isSidebarOpen ? "Hide node palette" : "Show node palette"}
          placement="right"
          arrow
        >
          <Box sx={{
            position: 'absolute',
            left: isSidebarOpen ? 240 : 0,
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 1000,
            backgroundColor: 'white',
            borderRadius: '0 4px 4px 0',
            boxShadow: 2,
            transition: 'left 0.3s ease',
          }}>
            <IconButton onClick={toggleSidebar} size="small" sx={{ p: 0.5 }}>
              {isSidebarOpen ? <PanelLeftClose size={20} /> : <PanelLeftOpen size={20} />}
            </IconButton>
          </Box>
        </Tooltip>
        
        {/* Right sidebar toggle */}
        <Tooltip 
          title={isRightSidebarOpen ? "Hide inspector" : "Show inspector"}
          placement="left"
          arrow
        >
          <Box sx={{
            position: 'absolute',
            right: isRightSidebarOpen ? rightSidebarWidth : 0,
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 1200,
            backgroundColor: 'white',
            borderRadius: '4px 0 0 4px',
            boxShadow: 2,
            transition: 'right 0.3s ease',
          }}>
            <IconButton onClick={toggleRightSidebar} size="small" sx={{ p: 0.5 }}>
              {isRightSidebarOpen ? <PanelRightClose size={20} /> : <PanelRightOpen size={20} />}
            </IconButton>
          </Box>
        </Tooltip>
        
        {/* Left Sidebar */}
        <Box sx={{ 
          position: 'absolute',
          width: 240,
          height: '100%',
          transform: isSidebarOpen ? 'translateX(0)' : 'translateX(-100%)',
          transition: 'transform 0.3s ease',
          top: 48,
        }}>
          <Sidebar />
        </Box>
        
        {/* Right Sidebar */}
        <Box sx={{ 
          position: 'absolute',
          width: rightSidebarWidth,
          height: '100%',
          right: 0,
          transform: isRightSidebarOpen ? 'translateX(0)' : 'translateX(100%)',
          transition: isRightSidebarOpen ? 'transform 0.3s ease, width 0.3s ease' : 'transform 0.3s ease',
          top: 48,
        }}>
          <RightSidebar />
        </Box>
        
        {/* Main Content */}
        <Box sx={{ 
          position: 'relative',
          width: '100%',
          height: '100%',
          marginLeft: isSidebarOpen ? '240px' : 0,
          marginRight: isRightSidebarOpen ? `${rightSidebarWidth}px` : 0,
          marginTop: '48px',
          transition: 'margin 0.3s ease',
        }}>
          <ReactFlowProvider>
            <Flow />
          </ReactFlowProvider>
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;