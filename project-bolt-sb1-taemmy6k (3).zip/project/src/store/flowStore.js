import { create } from 'zustand';
import {
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
} from 'reactflow';

export const useStore = create((set, get) => ({
  nodes: [],
  edges: [],
  selectedNode: null,
  isSidebarOpen: true,
  isRightSidebarOpen: true,
  rightSidebarWidth: 240,
  onNodesChange: (changes) => {
    set({
      nodes: applyNodeChanges(changes, get().nodes),
    });
  },
  onEdgesChange: (changes) => {
    set({
      edges: applyEdgeChanges(changes, get().edges),
    });
  },
  onConnect: (connection) => {
    const sourceNode = get().nodes.find(node => node.id === connection.source);
    let label = 'next';
    
    if (sourceNode?.data.type === 'database') {
      label = connection.sourceHandle === 'success' ? 'success' : 'error';
    }

    const edge = {
      ...connection,
      id: `e${connection.source}-${connection.target}`,
      label,
      labelStyle: { fill: '#666', fontSize: 8 },
      labelBgStyle: { fill: 'white' },
      labelBgPadding: [2, 1],
      labelBgBorderRadius: 2,
    };

    set({
      edges: addEdge(edge, get().edges),
    });
  },
  addNode: (node) => {
    set({
      nodes: [...get().nodes, node],
    });
  },
  deleteNode: (nodeId) => {
    set({
      nodes: get().nodes.filter((node) => node.id !== nodeId),
      edges: get().edges.filter(
        (edge) => edge.source !== nodeId && edge.target !== nodeId
      ),
    });
  },
  openConfigDrawer: (node) => {
    set({ selectedNode: node });
  },
  closeConfigDrawer: () => {
    set({ selectedNode: null });
  },
  updateNodeData: (nodeId, data) => {
    set({
      nodes: get().nodes.map((node) =>
        node.id === nodeId ? { ...node, data } : node
      ),
    });
  },
  toggleSidebar: () => {
    set((state) => ({ isSidebarOpen: !state.isSidebarOpen }));
  },
  toggleRightSidebar: () => {
    set((state) => ({ isRightSidebarOpen: !state.isRightSidebarOpen }));
  },
  setRightSidebarWidth: (width) => {
    set({ rightSidebarWidth: Math.max(200, Math.min(width, 600)) });
  },
}));