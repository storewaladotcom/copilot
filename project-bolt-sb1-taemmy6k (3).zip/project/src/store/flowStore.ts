import { create } from 'zustand';
import {
  Connection,
  Edge,
  EdgeChange,
  Node,
  NodeChange,
  addEdge,
  OnNodesChange,
  OnEdgesChange,
  OnConnect,
  applyNodeChanges,
  applyEdgeChanges,
} from 'reactflow';

type RFState = {
  nodes: Node[];
  edges: Edge[];
  selectedNode: Node | null;
  isSidebarOpen: boolean;
  onNodesChange: OnNodesChange;
  onEdgesChange: OnEdgesChange;
  onConnect: OnConnect;
  addNode: (node: Node) => void;
  deleteNode: (nodeId: string) => void;
  openConfigDrawer: (node: Node) => void;
  closeConfigDrawer: () => void;
  updateNodeData: (nodeId: string, data: any) => void;
  toggleSidebar: () => void;
};

export const useStore = create<RFState>((set, get) => ({
  nodes: [],
  edges: [],
  selectedNode: null,
  isSidebarOpen: true,
  onNodesChange: (changes: NodeChange[]) => {
    set({
      nodes: applyNodeChanges(changes, get().nodes),
    });
  },
  onEdgesChange: (changes: EdgeChange[]) => {
    set({
      edges: applyEdgeChanges(changes, get().edges),
    });
  },
  onConnect: (connection: Connection) => {
    const sourceNode = get().nodes.find(node => node.id === connection.source);
    let label = 'next';
    
    // If it's a database node, use the specific output port label
    if (sourceNode?.data.type === 'database') {
      label = connection.sourceHandle === 'success' ? 'success' : 'error';
    }

    const edge: Edge = {
      ...connection,
      id: `e${connection.source}-${connection.target}`,
      label,
      labelStyle: { fill: '#666', fontSize: 8 },
      labelBgStyle: { fill: 'white' },
      labelBgPadding: [2, 1],
      labelBgBorderRadius: 2,
    };

    set({
      edges: addEdge(edge, get().edges),
    });
  },
  addNode: (node: Node) => {
    set({
      nodes: [...get().nodes, node],
    });
  },
  deleteNode: (nodeId: string) => {
    set({
      nodes: get().nodes.filter((node) => node.id !== nodeId),
      edges: get().edges.filter(
        (edge) => edge.source !== nodeId && edge.target !== nodeId
      ),
    });
  },
  openConfigDrawer: (node: Node) => {
    set({ selectedNode: node });
  },
  closeConfigDrawer: () => {
    set({ selectedNode: null });
  },
  updateNodeData: (nodeId: string, data: any) => {
    set({
      nodes: get().nodes.map((node) =>
        node.id === nodeId ? { ...node, data } : node
      ),
    });
  },
  toggleSidebar: () => {
    set((state) => ({ isSidebarOpen: !state.isSidebarOpen }));
  },
}));